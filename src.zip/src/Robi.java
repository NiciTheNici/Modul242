public class Robi {

    private RobiAPI robi;


    // Used to start the Robi
    public static void main(String[] args) {
        Robi r = new Robi("localhost",49861);   // Tragen Sie hier die Portnummer auf Ihrem Simulator ein.
        // hier Robi Methoden aufrufen
        r.templateMethod();


    }

    public Robi(String hostname, int portNummer) {
        robi = new RobiAPI(hostname, portNummer);
    }

    /*
     *	Template-Methode für den Robi
     */
    public void templateMethod() {
        // Variabel deklarieren



        robi.connect();                  // ab hier ist der Robi verbunden

        // State-Machine



        robi.disconnect();              // hier wird der Robi wieder disconected


    }

}
